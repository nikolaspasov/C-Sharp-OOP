﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Zoo
{
    public class Animal
    {
        public string Name;
        public Animal(string name)
        {
            Name = name;
        }
    }
}
