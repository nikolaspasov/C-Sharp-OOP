﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoulMaster soulMaster = new SoulMaster("Gogata", 15);
            System.Console.WriteLine(soulMaster);
        }
    }
}