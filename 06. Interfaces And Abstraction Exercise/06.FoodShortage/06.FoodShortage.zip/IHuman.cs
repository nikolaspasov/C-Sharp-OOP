﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl
{
    public interface IHuman
    {
        string Name { get; }
        int Age { get; }
        string Id { get; }
        string Birthdate { get; }
    }
}
