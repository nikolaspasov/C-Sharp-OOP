﻿using _01.SingleInheritance;
using System;

namespace Farm
{
     public class StartUp
    {
        static void Main(string[] args)
        {
            Dog peshaka = new Dog();

            peshaka.Eat();
            peshaka.Bark();
        }
    }
}
