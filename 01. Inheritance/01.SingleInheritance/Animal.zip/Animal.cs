﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.SingleInheritance
{
   public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
