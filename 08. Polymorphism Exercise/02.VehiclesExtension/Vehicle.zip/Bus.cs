﻿using _01._Vehicles;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace _02.VehiclesExtension
{
    public class Bus : Vehicle
    {
        public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity, bool isEmpty)
       : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
            
        }

       


    }
}
