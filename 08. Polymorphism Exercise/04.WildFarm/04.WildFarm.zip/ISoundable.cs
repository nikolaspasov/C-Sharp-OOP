﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm
{
    public interface ISoundable
    {
        public void AskFood();
       
    }
}
